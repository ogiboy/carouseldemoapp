'use client'

import Carousel from '@/components/Carousel'

const HomePage = () => {
  return (
    <div className="App">
      <h1>Carousel Demo</h1>
      <Carousel />
    </div>
  )
}
export default HomePage
